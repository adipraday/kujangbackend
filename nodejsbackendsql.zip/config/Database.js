import { Sequelize } from "sequelize";

const db = new Sequelize(
  "u1737976_kujangbackend",
  "u1737976_kujangbackend",
  "sk1n3t@2024",
  {
    host: "localhost",
    dialect: "mysql",
  }
);

export default db;
